library(officer)
library(flextable)
## READ IN YOUR MAIN DOCUMENT
my_doc<- read_docx("_report.docx")

# Figures
my_doc<- body_add_par(my_doc, value = "Figures", style = "heading 1")

## FIGURE 1 - A STUDY AREA MADE OUTSIDE R
my_doc<- body_add_img(my_doc,src = "figure-1-yellowstone-study-area.png",  
    width = 6.5, height = 6.5, pos = "after")
my_doc <- body_add_par(my_doc,"Figure 1. Study area.", style = "caption")
my_doc<- body_add_break(my_doc)

## FIGURE 2 - A FIGURE MADE IN R
src <- tempfile(fileext = ".png")
png(filename = src, width = 6.5, height = 6.5, units = 'in', res = 300)
hist(rnorm(1000,0,1))
dev.off()

my_doc<- body_add_img(my_doc,src = src,  
    width = 6.5, height = 6.5, pos = "after")
my_doc <- body_add_par(my_doc,"Figure 2. Caption goes here.", style = "caption")
my_doc<- body_add_break(my_doc)

## FIGURE 3 - A FIGURE MADE IN R
src <- tempfile(fileext = ".png")
png(filename = src, width = 6.5, height = 6.5, units = 'in', res = 300)
hist(rnorm(1000,0,1))
dev.off()

my_doc<- body_add_img(my_doc,src = src,  
    width = 6.5, height = 6.5, pos = "after")
my_doc <- body_add_par(my_doc,"Figure 3. Caption goes here.", style = "caption")
my_doc<- body_end_section_continuous(my_doc)


## FIGURE 4 - A FIGURE MADE IN R--- but landscape
src <- tempfile(fileext = ".png")
png(filename = src, width = 9, height = 5.5, units = 'in', res = 300)
hist(rnorm(1000,0,1))
dev.off()

my_doc<- body_add_img(my_doc,src = src,  
    width = 9, height = 5.5, pos = "after")
my_doc <- body_add_par(my_doc,"Figure 4. Caption goes here.", style = "caption")
my_doc<- body_end_section_landscape(my_doc)


# TABLES
my_doc<- body_add_par(my_doc, value = "Tables", style = "heading 1")
## TABLE 1---
tbl1<-data.frame(treatment=rep(letters[1:3],5),
    measurement1=rnorm(15,0.1),
    measurement2=rnorm(15,0.1),
    measurement3=rnorm(15,0.1),
    measurement4=rnorm(15,0.1),
    other=runif(15,1000,10000))
tbl1<-tbl1[order(tbl1$treatment),]
indx<-c("treatment","measurement1","measurement2","measurement3","other")
tbl1<-flextable(tbl1,col_keys=indx)
tbl1<-set_header_labels(tbl1,
    values = list(
        treatment="Treatment",
        measurement1="1",
        measurement2="2",
        measurement3="3",
        other="Other measurement"))
tbl1 <- add_header(tbl1, values = list(
        measurement1="Occasion",
        measurement2="Occasion",     
        measurement3="Occasion"), top = TRUE)
## ALIGN THE FIRST ROW AND COLUMNS 1 TO 4: CENTERD
tbl1 <- align(tbl1,i=1,j=1:4,align="center",part="header")
## HORIZONTAL MERGE OF THE HEADER    
tbl1 <- merge_h(tbl1, part = "header")
## MERGE THE TREATMENT CELLS
tbl1 <- merge_v(tbl1,j = c("treatment"))
## VERTICAL ALIGN THE TREATMENT COLUMNS (j=1) 
## IN THE BODY TO THE TOP
tbl1<-valign(tbl1,j = 1, valign = 'top',part="body")



## FORMAT THE FONT AND THE FONT SIZE IN THE TABLE
tbl1 <- font(tbl1, fontname = "Georgia",part="all")
tbl1 <- fontsize(tbl1, size = 11)

## NOW TO FIX THE BORDERS
border<-fp_border(color="black", width = 1)
## REMOVE THE BORDER
tbl1<-border_remove(tbl1)
## ADD A HORIZONTAL LINE IN THE HEADER ON THE FIRST ROW
## AND COLUMNS 2-4
tbl1<-hline(tbl1,i=1,j=2:4,part="header",border = border)
## ADD A LINE AT THE BOTTOM OF THE BODY
tbl1 <- hline_bottom(tbl1, part="body",border = border)
## ADD A LINE AT THE BOTTOM OF THE HEADER
tbl1 <- hline_bottom(tbl1, part="header",border = border)
## ADD A LINE AT THE TOP OF THE HEADER
tbl1 <- hline_top(tbl1, part="header",border = border)
tbl1<-autofit(tbl1)
my_doc<- body_add_par(my_doc, value = "Table 1. caption.",
    style = "caption")
my_doc<- body_add_flextable(my_doc, tbl1)
my_doc<- body_end_section_continuous(my_doc)

## TABLE 2--- A LONG TABLE IN LANDSCAPE
tbl1<-data.frame(treatment=rep(letters[1:3],50),
    measurement1=rnorm(150,0.1),
    measurement2=rnorm(150,0.1),
    measurement3=rnorm(150,0.1),
    measurement4=rnorm(150,0.1),
    other=runif(150,1000,10000))
tbl1<-tbl1[order(tbl1$treatment),]
indx<-c("treatment","measurement1","measurement2","measurement3","other")
tbl1<-flextable(tbl1,col_keys=indx)
tbl1<-set_header_labels(tbl1,
    values = list(
        treatment="Treatment",
        measurement1="1",
        measurement2="2",
        measurement3="3",
        other="Other measurement"))
tbl1 <- add_header(tbl1, values = list(
        measurement1="Occasion",
        measurement2="Occasion",     
        measurement3="Occasion"), top = TRUE)
## ALIGN THE FIRST ROW AND COLUMNS 1 TO 4: CENTERD
tbl1 <- align(tbl1,i=1,j=1:4,align="center",part="header")
## HORIZONTAL MERGE OF THE HEADER    
tbl1 <- merge_h(tbl1, part = "header")
## MERGE THE TREATMENT CELLS
tbl1 <- merge_v(tbl1,j = c("treatment"))
## VERTICAL ALIGN THE TREATMENT COLUMNS (j=1) 
## IN THE BODY TO THE TOP
tbl1<-valign(tbl1,j = 1, valign = 'top',part="body")
## FORMAT THE FONT AND THE FONT SIZE IN THE TABLE
tbl1 <- font(tbl1, fontname = "Georgia",part="all")
tbl1 <- fontsize(tbl1, size = 11)
## NOW TO FIX THE BORDERS
border<-fp_border(color="black", width = 1)
## REMOVE THE BORDER
tbl1<-border_remove(tbl1)
## ADD A HORIZONTAL LINE IN THE HEADER ON THE FIRST ROW
## AND COLUMNS 2-4
tbl1<-hline(tbl1,i=1,j=2:4,part="header",border = border)
## ADD A LINE AT THE BOTTOM OF THE BODY
tbl1 <- hline_bottom(tbl1, part="body",border = border)
## ADD A LINE AT THE BOTTOM OF THE HEADER
tbl1 <- hline_bottom(tbl1, part="header",border = border)
## ADD A LINE AT THE TOP OF THE HEADER
tbl1 <- hline_top(tbl1, part="header",border = border)
tbl1<-autofit(tbl1)
my_doc<- body_add_par(my_doc, value = "Table 2. caption.",
    style = "caption")
my_doc<- body_add_flextable(my_doc, tbl1)
my_doc<- body_end_section_landscape(my_doc)

print(my_doc, target = paste("_report-draft-",Sys.Date(),".docx",sep=""))





